<div class="footer text-muted"> &copy; <?php echo date('Y'); ?>. <a href="#">Tourz CRM</a> by <a href="http://www.digitalpoin8.com/" target="_blank">DigitalPoin8</a> </div>


<script> 
	$(document).ready(function(){  
		$('.cstm_select2').select2({
			minimumResultsForSearch: Infinity
		});
	});  
</script>
