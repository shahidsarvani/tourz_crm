<!-- Footer -->

<div class="footer text-muted text-center"> &copy; <?php echo date('Y'); ?>. <a href="#">Tourz CRM</a> by <a href="http://www.digitalpoin8.com/" target="_blank">DigitalPoin8</a> </div>
<!-- /footer -->