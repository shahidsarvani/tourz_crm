<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tourz CRM Admin Panel</title>
<meta name="keywords" content="Tourz CRM Admin Panel" />
<meta name="description" content="Tourz CRM Admin Panel">
<meta name="author" content="Tourz CRM Admin Panel"> 
<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="<?= asset_url();?>css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="<?= asset_url();?>css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="<?= asset_url();?>css/core.css" rel="stylesheet" type="text/css">
<link href="<?= asset_url();?>css/components.css" rel="stylesheet" type="text/css">
<link href="<?= asset_url();?>css/colors.css" rel="stylesheet" type="text/css">
<!-- /global stylesheets -->

<!-- Core JS files -->
<script type="text/javascript" src="<?= asset_url();?>js/plugins/loaders/pace.min.js"></script>
<script type="text/javascript" src="<?= asset_url();?>js/core/libraries/jquery.min.js"></script>
<script type="text/javascript" src="<?= asset_url();?>js/core/libraries/bootstrap.min.js"></script>
<script type="text/javascript" src="<?= asset_url();?>js/plugins/loaders/blockui.min.js"></script>
<!-- /core JS files -->

<!-- Theme JS files -->
<script type="text/javascript" src="<?= asset_url();?>js/core/app.js"></script>
<!-- /theme JS files -->
<script type="text/javascript" src="<?= asset_url(); ?>js/jquery.validate.js"></script>
